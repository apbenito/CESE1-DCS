# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: E:\TUD\Vivado_Projects\CE_Lab2\pico32_template\workspace\img_blur_system\_ide\scripts\systemdebugger_img_blur_system_standalone.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source E:\TUD\Vivado_Projects\CE_Lab2\pico32_template\workspace\img_blur_system\_ide\scripts\systemdebugger_img_blur_system_standalone.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -nocase -filter {name =~"APU*"}
rst -system
after 3000
targets -set -filter {jtag_cable_name =~ "Xilinx PYNQ-Z1 003017A4CE56A" && level==0 && jtag_device_ctx=="jsn-Xilinx PYNQ-Z1-003017A4CE56A-23727093-0"}
fpga -file E:/TUD/Vivado_Projects/CE_Lab2/pico32_template/workspace/img_blur/_ide/bitstream/design_1_wrapper.bit
targets -set -nocase -filter {name =~"APU*"}
loadhw -hw E:/TUD/Vivado_Projects/CE_Lab2/pico32_template/workspace/platform/export/platform/hw/design_1_wrapper.xsa -mem-ranges [list {0x40000000 0xbfffffff}] -regs
configparams force-mem-access 1
targets -set -nocase -filter {name =~"APU*"}
source E:/TUD/Vivado_Projects/CE_Lab2/pico32_template/workspace/img_blur/_ide/psinit/ps7_init.tcl
ps7_init
ps7_post_config
targets -set -nocase -filter {name =~ "*A9*#0"}
dow E:/TUD/Vivado_Projects/CE_Lab2/pico32_template/workspace/img_blur/Debug/img_blur.elf
configparams force-mem-access 0
targets -set -nocase -filter {name =~ "*A9*#0"}
con
