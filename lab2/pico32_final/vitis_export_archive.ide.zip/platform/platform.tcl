# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct E:\TUD\Vivado_Projects\pico32\workspace\platform\platform.tcl
# 
# OR launch xsct and run below command.
# source E:\TUD\Vivado_Projects\pico32\workspace\platform\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {platform}\
-hw {E:\TUD\Vivado_Projects\pico32\design_1_wrapper.xsa}\
-proc {ps7_cortexa9_0} -os {standalone} -out {E:/TUD/Vivado_Projects/pico32/workspace}

platform write
platform generate -domains 
platform active {platform}
platform generate
platform active {platform}
bsp reload
domain active {zynq_fsbl}
bsp reload
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
domain active {standalone_domain}
bsp reload
domain active {zynq_fsbl}
bsp reload
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
domain active {standalone_domain}
bsp reload
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
bsp reload
platform active {platform}
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
bsp reload
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
bsp reload
domain active {zynq_fsbl}
bsp reload
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
domain active {standalone_domain}
bsp reload
platform generate
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
platform generate -domains 
bsp reload
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform active {platform}
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
platform generate
platform clean
platform generate
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper-new.xsa}
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
bsp reload
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform active {platform}
bsp reload
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform active {platform}
bsp reload
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
bsp reload
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
bsp reload
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform active {platform}
platform config -updatehw {E:/TUD/Vivado_Projects/CE/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform active {platform}
platform config -updatehw {E:/TUD/Vivado_Projects/CE/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/CE/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/CE/pico32/design_1_wrapper.xsa}
platform generate -domains 
platform active {platform}
platform config -updatehw {E:/TUD/Vivado_Projects/CE/pico32_template/design_1_wrapper.xsa}
platform generate -domains 
bsp reload
platform generate -domains 
platform active {platform}
platform config -updatehw {E:/TUD/Vivado_Projects/CE/pico32_template/design_1_wrapper.xsa}
platform generate
platform config -updatehw {E:/TUD/Vivado_Projects/CE/pico32_template_b01/pico32_template/design_1_wrapper.xsa}
platform generate -domains 
platform active {platform}
platform config -updatehw {E:/TUD/Vivado_Projects/CE/pico32_template/design_1_wrapper.xsa}
platform generate
platform active {platform}
platform config -updatehw {E:/TUD/Vivado_Projects/CE/pico32_template/design_1_wrapper.xsa}
platform generate -domains 
platform clean
platform generate
platform generate -domains 
platform generate
platform active {platform}
platform config -updatehw {E:/TUD/Vivado_Projects/CE/pico32_template/design_1_wrapper.xsa}
platform generate -domains 
platform active {platform}
platform config -updatehw {E:/TUD/Vivado_Projects/CE_Lab2/pico32_template/design_1_wrapper.xsa}
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/CE_Lab2/pico32_template/new.xsa}
platform generate -domains 
platform config -updatehw {E:/TUD/Vivado_Projects/CE_Lab2/pico32_template/design_1_wrapper.xsa}
platform clean
platform generate
