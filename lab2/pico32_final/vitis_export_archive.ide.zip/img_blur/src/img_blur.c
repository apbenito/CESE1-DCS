
#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "sleep.h"
#include "xgpio.h"
#include "xbram.h"
#include "instruction.h"
#include "data.h"

/*
 * ADDRESS MAP
 * Memory:
 * Instruction :- 	MEMORY_BLOCK_AXI_BRAM_CTRL_2 => 0x4000_0000
 * Data :-			MEMORY_BLOCK_AXI_BRAM_CTRL_3 => 0x4200_0000
 *
 * GPIO
 * ZYNQ RGB LED: 	XPAR_PROCESSOR_INTERCONNECTS_ZYNQ_RGB_LED => 0x4120_0000
 * PICO TRAP INPUT: XPAR_PROCESSOR_INTERCONNECTS_INP_PICO_TRAP => 0X4122_0000
 * PICO Reset:		XPAR_RISCV_RESET_DEVICE_ID => 0x41210000
 * PICO LEDs:		GPIO_2 => 0x4001_0000
 */
int main()
{
    init_platform();

//---------------------------- Init GPIOs ----------------------------//
    XGpio reset, output, trap;
    XGpio_Initialize(&output, XPAR_PROCESSOR_INTERCONNECTS_ZYNQ_RGB_LED_DEVICE_ID);
   	XGpio_Initialize(&reset, XPAR_RISCV_RESET_DEVICE_ID);
   	XGpio_Initialize(&trap, XPAR_PROCESSOR_INTERCONNECTS_INP_PICO_TRAP_DEVICE_ID);
   	XGpio_SetDataDirection(&output, 1, 0);
   	XGpio_SetDataDirection(&reset, 1, 0);
   	XGpio_SetDataDirection(&trap, 1, 1);
   	XGpio_DiscreteWrite(&reset, 1, 0);

   	// Set Status LED to Green
   	XGpio_DiscreteWrite(&output, 1, 0x2);

   	// Init BRAM Controller
   	XBram BramData,BramInstr;
   	int Status;
   	XBram_Config *ConfigPtr;
   	ConfigPtr = XBram_LookupConfig(XPAR_MEMORY_BLOCK_AXI_BRAM_CTRL_3_S_AXI_BASEADDR);
   	if (ConfigPtr == (XBram_Config *) NULL) {
   		return XST_FAILURE;
   	}
   	Status = XBram_CfgInitialize(&BramData, ConfigPtr,ConfigPtr->CtrlBaseAddress);
   	if (Status != XST_SUCCESS) {
   		return XST_FAILURE;
   	}
   	ConfigPtr = XBram_LookupConfig(XPAR_MEMORY_BLOCK_AXI_BRAM_CTRL_2_S_AXI_BASEADDR);
   	if (ConfigPtr == (XBram_Config *) NULL) {
   		return XST_FAILURE;
   	}
   	Status = XBram_CfgInitialize(&BramInstr, ConfigPtr,ConfigPtr->CtrlBaseAddress);
   	if (Status != XST_SUCCESS) {
   		return XST_FAILURE;
   	}
    print("Successfully init\n");
    sleep(1);	// Sleep for 1 second

//---------------------------- Test the Baseline ISA ----------------------------//

    print("Starting Baseline ISA Test\n");

    // Load RISC-V Instructions Memory
    int j = 0;
	for (int i = 0; i < instruction_size; i=i+4) {
		XBram_WriteReg(XPAR_MEMORY_BLOCK_AXI_BRAM_CTRL_2_S_AXI_BASEADDR,i,instructions[j]);
		j++;
	}

    // Load RISC-V Data Memory
    j = 0;
    for (int i = 0; i < data_size; i=i+4) {
		XBram_WriteReg(XPAR_MEMORY_BLOCK_AXI_BRAM_CTRL_3_S_AXI_BASEADDR,i,data[j]);
		j++;
	}
    xil_printf("Programming done\n");

	// Start PicoRV32 Processor
	XGpio_DiscreteWrite(&reset, 1, 1);

	// Set Status LED to Blue
	XGpio_DiscreteWrite(&output, 1, 0x4);

	// Loop till RISC-V processor has completed processing
	int cycle_count;
	while(1){
		cycle_count = XBram_ReadReg(0x42003500,0);
		if (cycle_count != 0){
			xil_printf("Program Completed with %d cycles\n",cycle_count);
			break;
		}
		if (XGpio_DiscreteRead(&trap,1)){	// Check if Pico TRAP signal is high
			xil_printf("Pico Processor Trap Occured\n");
			xil_printf("Aborting program\n");
			cleanup_platform();
			exit(1);
		}
		sleep(1);
	}
	XGpio_DiscreteWrite(&reset, 1, 0); // Reset the PICO processor

	//Verify the processed blur image
	int img_blur = 1;
	int pix;
	for(int i=0; i<32*32; i++){
		pix = XBram_ReadReg(0x42002000,i*4);
		if (pix != processed_data[i]){
			img_blur = 0;
		}
	}
	if(img_blur){
		xil_printf("Image has been blurred correctly\n");
		// Set Status LED to Green
		XGpio_DiscreteWrite(&output, 1, 0x2);
	}
	else{
		xil_printf("Image has been blurred incorrectly\n");
		// Set Status LED to Red
		XGpio_DiscreteWrite(&output, 1, 0x1);
	}

//---------------------------- Reset BRAMs ----------------------------//

	// RESET the BRAMS
	xil_printf("Reseting the BRAMs\n");

	XGpio_DiscreteWrite(&output, 1, 0x2);

	// Reset RISC-V Instructions Memory
	j = 0;
	for (int i = 0; i < instruction_size; i=i+4) {
		XBram_WriteReg(XPAR_MEMORY_BLOCK_AXI_BRAM_CTRL_2_S_AXI_BASEADDR,i,0);
		j++;
	}

	// Reset RISC-V Data Memory
	j = 0;
	for (int i = 0; i < data_size; i=i+4) {
		XBram_WriteReg(XPAR_MEMORY_BLOCK_AXI_BRAM_CTRL_3_S_AXI_BASEADDR,i,0);
		j++;
	}
	for(int i=0; i<32*32; i++){
		XBram_WriteReg(0x42002000,i*4, 0x0);
	}

	// Reset Cycle Count
	XBram_WriteReg(0x42003500,0,0x0);

//---------------------------- Test the Modified ISA ----------------------------//

	print("\n\nStarting Modified ISA Test\n");

	// Load RISC-V Instructions Memory
	j = 0;
	for (int i = 0; i < instruction_mod_size; i=i+4) {
		XBram_WriteReg(XPAR_MEMORY_BLOCK_AXI_BRAM_CTRL_2_S_AXI_BASEADDR,i,instructions_modified[j]);
		j++;
	}

	// Load RISC-V Data Memory
	j = 0;
	for (int i = 0; i < data_size; i=i+4) {
		XBram_WriteReg(XPAR_MEMORY_BLOCK_AXI_BRAM_CTRL_3_S_AXI_BASEADDR,i,data[j]);
		j++;
	}
	xil_printf("Programming done\n");

	// Start PicoRV32 Processor
	XGpio_DiscreteWrite(&reset, 1, 1);

	// Set Status LED to Blue
	XGpio_DiscreteWrite(&output, 1, 0x4);

	// Loop till RISC-V processor has completed processing
	while(1){
		cycle_count = XBram_ReadReg(0x42003500,0);
		if (cycle_count != 0){
			xil_printf("Program Completed with %d cycles\n",cycle_count);
			break;
		}
		if (XGpio_DiscreteRead(&trap,1)){	// Check if Pico TRAP signal is high
			xil_printf("Pico Processor Trap Occured\n");
			xil_printf("Aborting program\n");
			cleanup_platform();
			exit(1);
		}
		sleep(1);
	}
	XGpio_DiscreteWrite(&reset, 1, 0); // Reset the PICO processor

	//Verify the processed blur image
	img_blur = 1;
	for(int i=0; i<32*32; i++){
		pix = XBram_ReadReg(0x42002000,i*4);
		if (pix != processed_data[i]){
			img_blur = 0;
		}
	}
	if(img_blur){
		xil_printf("Image has been blurred correctly\n");
		// Set Status LED to Green
		XGpio_DiscreteWrite(&output, 1, 0x2);
	}
	else{
		xil_printf("Image has been blurred incorrectly\n");
		// Set Status LED to Red
		XGpio_DiscreteWrite(&output, 1, 0x1);
	}


//	// Display the processed values on the UART port
//	int temp;
//	for(int i=0; i< 32*32*4; i=i+4){
//		temp = XBram_ReadReg(0x42002000,i);
//		xil_printf("%x,",temp);
//	}

    cleanup_platform();
    return 0;
}
